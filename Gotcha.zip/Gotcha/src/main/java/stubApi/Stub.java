package stubApi;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

@Controller
@EnableAutoConfiguration
public class Stub {
    @Value("${classpath:/relationship.json}")
    ClassPathResource relationship;

    @GetMapping(value = "/api/investments-summary/client/relationship/", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    String relationship() throws IOException {
        try(InputStream inputStream = relationship.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        }
    }


    @Value("${classpath:/directionTrustCategory.json}")
    ClassPathResource directionTrustCategory;

    @GetMapping(value = "/api/investments-summary/view/direction/trust/category/", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    String directionTrustCategory() throws IOException {
        try(InputStream inputStream = directionTrustCategory.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        }
    }

    @Value("${classpath:/directionBrokerProduct.json}")
    ClassPathResource directionBrokerProduct;

    @GetMapping(value = "/api/investments-summary/view/direction/broker/product/", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    String directionBrokerProduct() throws IOException {
        try(InputStream inputStream = directionBrokerProduct.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        }
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(Stub.class, args);
    }
}
